package contactservices.zip;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	public void testAdd() {
        ContactService cs = new ContactService();
        contact test1 = new contact("1234","Jessica", "Bains","1234567890", "798 Pumpkin Lane");
        assertEquals(true, cs.addcontact(test1));
    }

    public void testDelete() {
        ContactService cs = new ContactService();

        contact test1 = new contact("1234�, "Jessica�, �Bains�, �1234567890�, �798 Pumpkin Lane�);
        contact test2 = new contact(�3456�, �Pearl�, �Ray�, �0482942357�, �896 Pumpkin Lane�);
        contact test3 = new contact(�7890�, �Will�, �Smith�, �6663332094�, �427 Pumpkin Lane�);

        cs.addcontact(test1);
        cs.addcontact(test2);
        cs.addcontact(test3);

        assertEquals(true, cs.deletecontact(�1234�));
        assertEquals(false, cs.deletecontact(�1243�));
        assertEquals(false, cs.deletecontact(�1243�));
    }

public void testUpdate() {
        ContactService cs = new ContactService();

        contact test1 = new contact("1234�, "Jessica�, �Bains�, �1234567890�, �798 Pumpkin Lane�);
        contact test2 = new contact(�3456�, �Pearl�, �Ray�, �0482942357�, �896 Pumpkin Lane�);
        contact test3 = new contact(�7890�, �Will�, �Smith�, �6663332094�, �427 Pumpkin Lane�);

        cs.addcontact(test1);
        cs.addcontact(test2);
        cs.addcontact(test3);

        assertEquals(true, cs.updatecontacts(�3456�, �Pearl�, �Ray�, �0482942357�, �896 Pumpkin Lane�));
        assertEquals(false, cs.updatecontact(�3457�, �Pearl�, �Ray�, �0482942357�, �896 Pumpkin Lane�));
    }

}


