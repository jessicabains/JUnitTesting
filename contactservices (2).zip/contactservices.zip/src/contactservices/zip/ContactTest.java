package contactservices.zip;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testcontact() {
		contact contact = new contact("1234","Jessica","Bains","1234567890","798 Witch Lane");
		assertTrue(contact.getid().equals("1234"));
		assertTrue(contact.getfirstName().equals("Jessica"));
		assertTrue(contact.getlastName().equals("Bains"));
		assertTrue(contact.getphone().equals("1234567890"));
		assertTrue(contact.getaddress().equals("798 Witch Lane"));
	}
}
	