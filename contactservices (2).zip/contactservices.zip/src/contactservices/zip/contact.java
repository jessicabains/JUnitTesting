package contactservices.zip;

public class contact {
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	public contact(String id, String firstName, String lastName, String phone, String address) {
		if(id==null ||id.length()>10) {
			throw new IllegalArgumentException("Invalid id");
		}
		if(firstName==null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if(lastName==null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if(phone==null || phone.length()>10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if(address==null || address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;	
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id= id;
	}
	public String getfirstName() {
		return firstName;
	}
	public void setfirstName(String firstName) {
		this.firstName= firstName;
	}
	public String getlastName() {
		return lastName;
	}
	public void setlastName(String lastName) {
		this.lastName = lastName;
	}
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone= phone;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address= address;
	}
	public String toString() {
	return "Contact [id=" +id + ", firstName=" + firstName + ", lastName=" + lastName + ", Phone Number=" + phone + ", address=" + address + "]";
	
}
	
	
	
	