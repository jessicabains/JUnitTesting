package contactservices.zip;

import java.util.ArrayList;

public class ContactService {
	private ArrayList<contact> contacts;
	
public ContactService() {
        
        contacts = new ArrayList<>();
    }
    public boolean addcontact(contact contact) {
        boolean contactAlready = false;
        
        for (contact contactList : contacts) {
        
            if (contactList.equals(contact)) {
                contactAlready = true;
            }
        }
      
        if (!contactAlready) {
            contacts.add(contact);
           
            return true;
        } else {
            return false;
        }
    }

   
    public boolean deleteContact(String string) {
       
       for (contact contactList : contacts) {
          
            if (contactList.getid().equals(string)) {
               
                contacts.remove(contactList);
                return true;
            }
        }
        return false;
    }
    public boolean updateContact(String id, String firstName, String lastName, String phone, String address) {
    	for( contact contactList: contacts) {
    	
    
    	if (contactList.getid().equals(id)) {
    		if (!firstName.equals("") && !(firstName.length() > 10)) {
    			contactList.setfirstName(firstName);
        }
    		if (!lastName.equals("") && !(lastName.length() > 10)) {
    			contactList.setfirstName(lastName);
        }
    		if (!phone.equals("") && (phone.length() == 10)) {
    			contactList.setfirstName(phone);
        }
    		if (!address.equals("") && !(address.length() > 30)) {
    			contactList.setfirstName(address);
        }
    		return true;
    }
}
    	return false;
}
}